'use client';
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/components/ui/use-toast";
import { useSwarmSessions } from "@/lib/hooks/use-swarm-sessions";
import { useSupabaseUser } from "@/lib/providers/supabase-user-provider";
import { StatusUpdate, Update, useSwarm, Task, ErrorUpdate, TaskCallback, MessageUpdate } from "@/lib/providers/swarm-provider";
import { Message, ProcessState } from "@/models/local/types";
import { useEffect, useState } from "react";
import { useMutation } from 'react-query';

const ComponentTypes = {
    TEXT: 1,
    RADIO: 2,
    CHECKBOX: 3,
    DROPDOWN: 4,
    DATE: 5,
    NUMBER: 6,
};

type AnswersState = { [key: string]: any };

export type IntakePageProps = {
    // Add props here
    formId: string;
};

export const IntakePage = ({formId}: IntakePageProps) => {
    const { user } = useSupabaseUser();
    const [processState, setProcessState] = useState<ProcessState>('NOT CONNECTED');
    const [currentGroupIndex, setCurrentGroupIndex] = useState(0);
    const [questionnaireData, setQuestionnaireData] = useState<any>(null);
    const [sessionId, setSessionId] = useState('');
    const [task_id, setTaskId] = useState('');
    const [form, setForm] = useState('');
    const [answers, setAnswers] = useState<AnswersState[]>(questionnaireData?.questiongroups?.map((group: any) =>
        group?.questions?.reduce((acc: any, question: any, index: any) => {
                acc[index.toString()] = ''; // Initialize each answer with an empty string
                return acc;
            }, {} as AnswersState)
        ));

    const { subscribeToSession, unsubscribeFromSession, sendMessage, sendCallback, sendError, sendTask, setUpdateHandler } = useSwarm();

    useEffect(() => {
        // Define a function to handle updates immediately
        const immediateUpdateHandler = async (update: Update) => {
          console.log('Immediate update:', update);
            switch (update.type) {
              case 'status':
                await handleSocketStatusMessage(update.sessionId, update);
                break;
              case 'message':
                handleSocketSwarmMessage(update.sessionId, update);
                break;
              case 'error':
                handleSocketErrorMessage(update.sessionId, update.error);
                break;
              default:
                handleSocketUnknownMessage(update.sessionId, update);
                break;
            }
        };
        // Set the update handler to the immediateUpdateHandler
        setUpdateHandler(immediateUpdateHandler);

      return () => 
      {
        setUpdateHandler(() => {});
      }
    }, []);

    useEffect(() => {
        const data = {
            title: 'Veteran Intake Form',
            partial: 'true',
            _task: {
                callback: "https://api.vaclaims.io/api/v1/swarm/callback?_session_id=1&_task_id=1"
            },
            questiongroups: [
                {
                    title: 'Personal Information',
                    questions: [
                        {
                            label: 'First Name',
                            component: ComponentTypes.TEXT,
                        },
                        {
                            label: 'Last Name',
                            component: ComponentTypes.TEXT,
                        },
                        {
                            label: 'Date of Birth',
                            component: ComponentTypes.DATE,
                        },
                        {
                            label: 'Gender',
                            component: ComponentTypes.DROPDOWN,
                            options: ['Male', 'Female', 'Other'],
                        },
                    ],
                }
            ],
        };
        setQuestionnaireData(data);
            
        const newAnswers = data?.questiongroups?.map((group: any) =>
            group?.questions?.reduce((acc: any, question: any, index: any) => {
                acc[index.toString()] = ''; // Initialize each answer with an empty string
                return acc;
            }, {} as AnswersState)
        );
        setAnswers(newAnswers);
    }, []);


    useEffect(() => {
        if(!user) 
        {
            console.log('No user found, returning');
            return;
        }
        
        if(!formId)
        {
            console.log('No formId provided sending task to get initial intake form');
            sendTask(user?.id as string, sessionId, {task_id: null, task: {  target: 'QuestionnaireWriter', context: {instructions: 'generate an initial_intake'}}});
            console.log('Task sent to get initial intake form');
        }
    }, [user, formId]);

    const handleSocketStatusMessage = async (sessionId: string, eventData: StatusUpdate) => {
        console.log('Status message:', eventData);
        if (eventData.status) {
          console.log('Status:', eventData.status);
          switch(eventData.status) {
            case 'agency_initialized':
              console.log('Success:', eventData.status);
              handleProcessStateChange(sessionId, 'INITIALIZED');
              break;
            case 'task_completed':
              console.log('Success:', eventData.status);
              handleProcessStateChange(sessionId, 'COMPLETED');
              break;
            case 'new_task':
              console.log('New task started:', eventData.task_id);
              break;
            default:
              console.error('Unknown status:', eventData.status);
              break;
          }
        }
      };
      
      const handleSocketSwarmMessage = (sessionId: string, eventData: any) => {
        const { msg_type, message } = eventData;
        if(!msg_type) return;
        switch(msg_type) {
          case 'text':
            let newMessage: Message = { content: message, type: msg_type };
            if (eventData.message.includes('@User') || eventData.message.includes('User 🗣️')) {
              console.log('my_text message:', message);
              newMessage = { content: message, type: 'my_text' };
            } else {
              // If 'my_text' is not selected but 'text' is, add all 'text' messages
              console.log('text message:', message);
              newMessage = { content: message, type: msg_type };
            }
          case 'function_output':
            console.log('Function output:', message);
            setQuestionnaireData(message);
            break;
          default:
            console.error('Unknown message type:', msg_type);
            break;
        }
      }
    
      const handleSocketErrorMessage = (sessionId: string, eventData: any) => {
        console.error('Error:', eventData.error);
      };
    
      const handleSocketUnknownMessage = (sessionId: string, eventData: any) => {
        try {
          console.error('Unknown status:', JSON.stringify(eventData));
        } catch (error) {
          console.error('Could not stringify socket message:', error);
          console.error('Event Data:', eventData);
        }
      };

    const handleProcessStateChange = (sessionId: string, newState: ProcessState) => {
        setProcessState(newState);
        toast({
          title: 'Process State Changed',
          description: (
            <pre>{`Process state changed to ${newState} for session ${sessionId}`}</pre>
          )
        });
      };
    
      useEffect(() => {
        if (!user ) return;
        console.log('Sessions updated. Subscribing to sessions.');
        console.log('Subscribing ', user.id, 'to session:', sessionId);
        subscribeToSession(user.id, sessionId);
    
        return () => {
          if (user) {
            console.log('Unsubscribing from sessions.');
            console.log('Unsubscribing ', user.id, 'from session:', sessionId);
            unsubscribeFromSession(user.id, sessionId);
          }
        };
      }, [user]);

    // Define the mutation using useMutation hook
    const submitFormMutation = useMutation((newAnswers: AnswersState[]) => {
        // Replace this with the actual API call
        return fetch('/api/submit-form', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newAnswers),
        });
    });

    const handleSubmit = () => {
        // Call the mutation with the answers state
        submitFormMutation.mutate(answers, {
            onSuccess: () => {
                // Handle success, e.g., show a success message, redirect, etc.
            },
            onError: (error) => {
                // Handle error, e.g., show an error message
            },
        });
    };

    const handleInputChange = (groupIndex: number, questionIndex: string, value: any) => {
        // Clone the current answers state
        const newAnswers = [...answers];
        // Ensure a sub-object exists for the group
        newAnswers[groupIndex] = newAnswers[groupIndex] || {};
        // Update the answer for the specific question
        newAnswers[groupIndex][questionIndex] = value;
        // Set the new answers state
        setAnswers(newAnswers);
    };

    const isGroupComplete = (groupIndex: number) => {
        if (!answers) return false;
        // Implement logic to check if all required questions in the group have been answered
        // For now, we'll just check if the object has any keys
        return Object.keys(answers[groupIndex]).length > 0;
    };

    const handleNextGroup = () => {
        if(questionnaireData?.partial == "true")
        {
            //Submit the callback to the server
            questionnaireData._task.callback = questionnaireData._task.callback + "&_nextstep=review";
            //Call the TaskCallback on UseSwarm
            sendCallback(user?.id as string, sessionId, task_id, "complete", questionnaireData._task.callback);
        }
        if (currentGroupIndex < questionnaireData?.questiongroups?.length - 1) {
            setCurrentGroupIndex(currentGroupIndex + 1);
        }
    };

    const handlePreviousGroup = () => {
        if (currentGroupIndex > 0) {
            setCurrentGroupIndex(currentGroupIndex - 1);
        }
    };

    const progressPercentage = ((currentGroupIndex + 1) / questionnaireData?.questiongroups?.length) * 100;

    return (
        <>
        {!questionnaireData ? (
            <div className="flex flex-col w-full items-center justify-center gap-y-2 mt-10">
                <Skeleton className="flex flex-col w-4/5 items-center justify-center">
                    <div className="h-8 w-2/3 bg-gray-300 rounded"/>
                </Skeleton>
                <Skeleton className="flex flex-col w-4/5 items-center justify-center">
                    <div className="h-8 w-2/3 bg-gray-300 rounded"/>
                </Skeleton>
                <Skeleton className="flex flex-col w-4/5 items-center justify-center">
                    <div className="h-8 w-2/3 bg-gray-300 rounded"/>
                </Skeleton>
            </div>
        ) : (
        <div className="flex flex-col items-center justify-center">
            <Separator />
            {questionnaireData?.partial != "true" && (
            <>
            <Progress value={progressPercentage} />
            <div className="text-center text-sm font-semibold mt-2">{progressPercentage.toFixed(0)}%</div>
            </>
            )}
            <div className="flex w-full container flex-col">
                <h2 className="text-2xl font-semibold text-center">{questionnaireData?.questiongroups?.[currentGroupIndex]?.title}</h2>
                <p className="text-md text-gray-300 mt-2">Please answer the following questions to the best of your ability.</p>
                <div className="flex flex-col justify-between gap-3">
                    {questionnaireData?.questiongroups?.[currentGroupIndex]?.questions?.map((question: any, questionIndex: any) => {
                        return (
                            <div key={question?.label}>
                                <h3>{question?.label}</h3>
                                <div className="flex">
                                    {question.component === ComponentTypes.TEXT && (
                                        <textarea
                                            className="border border-gray-300 rounded px-2 py-1 w-full mt-2"
                                            value={answers[currentGroupIndex][questionIndex.toString()]}
                                            onChange={(e) => handleInputChange(currentGroupIndex, questionIndex.toString(), e.target.value)}
                                        />
                                    )}
                                    {question.component === ComponentTypes.RADIO && (
                                        <div>
                                            {question?.options?.map((option: any, index: any) => {
                                                return (
                                                    <label key={option}>
                                                        <input
                                                            type="radio"
                                                            value={option}
                                                            checked={answers[currentGroupIndex][questionIndex.toString()] === option}
                                                            onChange={() => handleInputChange(currentGroupIndex, questionIndex.toString(), option)}
                                                        />
                                                        {option}
                                                    </label>
                                                );
                                            })}
                                        </div>
                                    )}
                                    {question.component === ComponentTypes.CHECKBOX && (
                                        <div>
                                            {question?.options?.map((option: any, index: any) => {
                                                return (
                                                    <div key={option} className="ml-4">
                                                        <label key={option}>
                                                            <input
                                                                type="checkbox"
                                                                value={option}
                                                                checked={answers[currentGroupIndex][questionIndex.toString()] === option}
                                                                onChange={() => handleInputChange(currentGroupIndex, questionIndex.toString(), option)}
                                                            />
                                                            {option}
                                                        </label>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    )}
                                    {question.component === ComponentTypes.DROPDOWN && (
                                        <select
                                            value={answers[currentGroupIndex][questionIndex.toString()]}
                                            onChange={(e) => handleInputChange(currentGroupIndex, questionIndex.toString(), e.target.value)}
                                        >
                                            <option value="">Select an option</option>
                                            {question?.options?.map((option: any, index: any) => {
                                                return (
                                                    <option key={option} value={option}>
                                                        {option}
                                                    </option>
                                                );
                                            })}
                                        </select>
                                    )}
                                    {question.component === ComponentTypes.DATE && (
                                        <input
                                            type="date"
                                            value={answers[currentGroupIndex][questionIndex.toString()]}
                                            onChange={(e) => handleInputChange(currentGroupIndex, questionIndex.toString(), e.target.value)}
                                        />
                                    )}
                                    {question.component === ComponentTypes.NUMBER && (
                                        <input
                                            type="number"
                                            value={answers[currentGroupIndex][questionIndex.toString()]}
                                            onChange={(e) => handleInputChange(currentGroupIndex, questionIndex.toString(), e.target.value)}
                                        />
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
            <div className="flex justify-center mt-4">
                <button
                    onClick={handlePreviousGroup}
                    disabled={currentGroupIndex === 0}
                    className={`mx-2 px-4 py-2 rounded ${currentGroupIndex === 0 ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-blue-500 text-white hover:bg-blue-700'}`}
                >
                    Previous
                </button>
                <button
                    onClick={(currentGroupIndex !== questionnaireData?.questiongroups?.length - 1) || (questionnaireData?.partial == "true") ? handleNextGroup : handleSubmit}
                    disabled={!isGroupComplete(currentGroupIndex)}
                    className={`mx-2 px-4 py-2 rounded ${!isGroupComplete(currentGroupIndex) ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-green-500 text-white hover:bg-green-700'}`}
                >

                    {(currentGroupIndex !== questionnaireData?.questiongroups?.length - 1) || (questionnaireData?.partial == "true") ? 'Next' : 'Submit'}
                </button>
            </div>
        </div>
        )}
    </>
    );
};

export default IntakePage;
